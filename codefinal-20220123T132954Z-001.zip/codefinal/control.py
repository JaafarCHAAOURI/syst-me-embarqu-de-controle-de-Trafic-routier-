import csv

def  controle(num_mat):
    statut=''
    with open('C:/Users/user/Desktop/pfe/control.csv','r') as file:
        reader = csv.reader(file)
        for row in reader:
            if str(row[0])==str(num_mat):
              print('trouve')
              if str(row[1])== 'true' or str(row[2])== 'true':
                print('illegal')
                statut='illegal'
    return statut           
