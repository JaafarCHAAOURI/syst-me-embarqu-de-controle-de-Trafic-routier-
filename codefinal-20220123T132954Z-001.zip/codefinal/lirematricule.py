import numpy as np
import cv2
import random
import string  
import pandas as pd
def matriclire(image):
 image=cv2.resize(image,(1000,1016))
 label=x=y=w=h=None

 nettnbas=cv2.dnn.readNetFromDarknet("C:/Users/user/Desktop/custom-yolov4-tiny-detector.cfg","C:/Users/user/Desktop/custom-yolov4-tiny-detector_best.weights")
 nettnbas.setPreferableBackend(cv2.dnn.DNN_BACKEND_CUDA)
 nettnbas.setPreferableTarget(cv2.dnn.DNN_TARGET_CUDA)
 classestnbas=[]
 with open("C:/Users/user/Desktop/obj.names","r") as f:
        classestnbas = [line.strip() for line in f.readlines()]

 layer_namestnbas = nettnbas.getLayerNames()
 outputlayerstnbas = [layer_namestnbas[i[0] - 1] for i in nettnbas.getUnconnectedOutLayers()]
 
 B= []
 C=[]
 
 scale = 0.00392
 #image=cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
 try: 

  blob = cv2.dnn.blobFromImage(image,scale,(416,416),(0,0,0),True,crop=False)
  
  nettnbas.setInput(blob)
  outs = nettnbas.forward(outputlayerstnbas)
  
  Width = image.shape[1]
  Height = image.shape[0]
  class_ids = []
  confidences = []
  boxes = []
  conf_threshold = 0.5
  nms_threshold = 0.5
  column_names = ["label", "pos"]
  ##########
  lbl=[]
  poss=[]
  
  df = pd.DataFrame(columns = column_names)
  for out in outs:
    for detection in out:
     scores = detection[5:]
     class_id = np.argmax(scores)
     confidence = scores[class_id]
     if confidence >= 0.9:
        center_x = int(detection[0] * Width)
        center_y = int(detection[1] * Height)
        w = int(detection[2] * Width)
        h = int(detection[3] * Height)
        x = center_x - w / 2
        y = center_y - h / 2
        class_ids.append(class_id)
        confidences.append(float(confidence))
        boxes.append([round(x), round(y), round(w), round(h)])
  indices = cv2.dnn.NMSBoxes(boxes, confidences, conf_threshold, nms_threshold)
  
  
  
  #arr = np.empty((0,2),dtype=object) 
  my_rows, my_cols = (0, 2)
  arr = [[0]*my_cols]*my_rows
  for i in range(len(boxes)):
        if i in indices:
            x, y, w, h = boxes[i]
            print(type(x))
            label = str(classestnbas[class_ids[i]])
  
            arr.append([x,label])
            
            #arr=np.append(arr, [[int(x),str(label)]], axis = 0)
            
  arr=sorted(arr,key=lambda x: (x[0]))
        
  # Sort 2D numpy array by 2nd Column
  #arr = arr[arr[:,1].argsort()] 
  #arr=arr[np.argsort(arr[:,1])]
  #arr=arr[arr[:,1].argsort(), :]
  
  
  
  
  
  
  for i in arr: 
        print(type(i[0]))
        B.append(i[1]) 
       
  return(B)

 except Exception as e:
   print(e) 