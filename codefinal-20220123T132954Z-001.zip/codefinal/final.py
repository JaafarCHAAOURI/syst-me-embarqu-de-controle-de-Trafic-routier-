
import random
import numpy as np
import cv2
from lirematricule import matriclire
from control import controle
########################################################################################
#stream = CamGear(source="C:/Users/user/Desktop/pfe/3.mp4").start() 
########################################################################################

cap = cv2.VideoCapture("C:/Users/user/Desktop/pfe/3.mp4")
#cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
#cap.set(cv2.CAP_PROP_FRAME_WIDTH, 416)
#cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 416)
net = cv2.dnn.readNetFromDarknet("C:/Users/user/Desktop/dnns/customyolo/custom-yolov4-tiny-detector.cfg","C:/Users/user/Desktop/dnns/customyolo/custom-yolov4-tiny-detector_best.weights")
net.setPreferableBackend(cv2.dnn.DNN_BACKEND_CUDA)
net.setPreferableTarget(cv2.dnn.DNN_TARGET_CUDA)



indicator=''
classes = []  

with open("C:/Users/user/Desktop/dnns/customyolo/obj.names","r") as f:
    classes = [line.strip() for line in f.readlines()]  
layer_names = net.getLayerNames()

outputlayers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]
########################################################################################
#output = cv2.VideoWriter('C:/Users/user/Desktop/output.avi', cv2.VideoWriter_fourcc('M','J','P','G'), 20, (640,480))

#################################################################################"########
while cap.isOpened():
#while True:
   try:
    #image = stream.read()


    # Capture frame-by-frame
    ret, image = cap.read()
    image=cv2.resize(image,(3840,2160))
    cimage=image.copy()
    #cv2.line(img=image, pt1=(0, 1500), pt2=(image.shape[1], 1500), color=(255, 0, 0), thickness=5, lineType=8, shift=0)
    #cv2.line(img=image, pt1=(0, 2000), pt2=(image.shape[1], 2000), color=(255, 0, 0), thickness=5, lineType=8, shift=0)

    
    ######################
    if ret == True:
    #if  True:
     scale = 0.00392
     blob = cv2.dnn.blobFromImage(image,scale,(416,416),(0,0,0),True,crop=False)
     net.setInput(blob)
     outs = net.forward(outputlayers)
     #print(outs)
     Width = image.shape[1]
     Height = image.shape[0]
     class_ids = []
     confidences = []
     boxes = []
     conf_threshold = 0.5
     nms_threshold = 0.5
     for out in outs:
       for detection in out:
         scores = detection[5:]
         class_id = np.argmax(scores)
         confidence = scores[class_id]
         if confidence > 0.7:
           center_x = int(detection[0] * Width)
           center_y = int(detection[1] * Height)
           w = int(detection[2] * Width)
           h= int(detection[3] * Height)
           x = center_x - w / 2
           y = center_y - h / 2
           class_ids.append(class_id)
           confidences.append(float(confidence))
           boxes.append([round(x), round(y), round(w), round(h)])
     indices = cv2.dnn.NMSBoxes(boxes, confidences, conf_threshold, nms_threshold)
     #----------------------------OCR---------------------------------------------------------------
     #cropping detected objects and passing into tesseract OCR
     A = []
     vv=True 
     if indices is not None:

      for i in indices:
        num_mat=[]
        
        verif=True
        i = i[0]
        box = boxes[i]
        x = box[0]
        y = box[1]
        w = box[2]
        h = box[3]
        xxx=x
        yyy=y
        www=w
        hhh=h
        plate= image[y:y+h, x:x+w]
        # Draw a rectangle with blue line borders of thickness of 2 px
        image = cv2.rectangle(image, (x,y), (x+w,y+h), (255, 0, 0), 1)     

        #*******************************************************************************
        if vv:
        #if y == 686 :
        #print(y)
        #if y == 1734:
        #if  y<2000 and y >1100  :
            
            print("allllooo")
            print(y)
            S = 10  # number of characters in the string.  
            # call random.choices() string module to find the string in Uppercase + numeric data.  
            num_mat=matriclire(plate)
            fps = cap.get(cv2.CAP_PROP_FPS)
            print("Frames per second using video.get(cv2.CAP_PROP_FPS) : {0}".format(fps))
            window_name = 'frame'
              
            # font
            font = cv2.FONT_HERSHEY_SIMPLEX
              
            # org
            org = (20, 20)
              
            # fontScale
            fontScale = 2
               
            # Blue color in BGR
            color = (255, 255, 0)
              
            # Line thickness of 2 px
            thickness = 6
            print(num_mat)
            str1 = ''.join(str(e) for e in num_mat)
            indicator=controle(str1)
            if indicator=='illegal':
               
               # Using cv2.putText() method
               cimage = cv2.putText(image, str(num_mat), (xxx-20,yyy+10), font, fontScale, (255,0,0) , thickness, cv2.LINE_AA)
            else: 
               cimage = cv2.putText(image, str(num_mat), (xxx-20,yyy+10), font, fontScale, (0,255,0)  , thickness, cv2.LINE_AA)                                          
     cv2.namedWindow("a", cv2.WINDOW_NORMAL)
     cv2.imshow("a", cimage)
     #output.write(cimage)
     if cv2.waitKey(1) & 0xFF == ord('q'):
        break
        
    ##########################################################################################"    
    else:
     break

   except Exception as e:
        print(e)   
# When everything done, release the capture
cap.release()
#stream.stop()
cv2.destroyAllWindows()           



     